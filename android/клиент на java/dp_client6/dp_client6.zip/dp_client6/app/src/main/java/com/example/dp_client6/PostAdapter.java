package com.example.dp_client6;

public class PostAdapter {
}
